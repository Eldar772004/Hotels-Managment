public class getPrivilege {
}
