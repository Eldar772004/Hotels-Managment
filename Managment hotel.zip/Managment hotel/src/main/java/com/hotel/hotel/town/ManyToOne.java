package com.hotel.hotel.town;

public @interface ManyToOne {
    boolean optional();
}
