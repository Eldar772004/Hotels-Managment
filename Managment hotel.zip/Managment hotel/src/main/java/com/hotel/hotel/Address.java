package com.hotel.hotel;

public interface Address {
}
