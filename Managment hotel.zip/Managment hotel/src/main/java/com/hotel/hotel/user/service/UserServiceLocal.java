package com.hotel.hotel.user.service;

import com.hotel.hotel.UserService;
import com.hotel.hotel.address.List;
import com.hotel.hotel.user.User;

public @interface  UserServiceLocal {
     UserServiceLocal USER_SERVICE = new UserService();

    public List<User> FindAll = null;

   User Login(String username,String password);

   java.util.List<User> findall();

}
}
}
  voidSave(User user);

    UserServiceLocal save();

    void save(User user);

    void delete(User user)
