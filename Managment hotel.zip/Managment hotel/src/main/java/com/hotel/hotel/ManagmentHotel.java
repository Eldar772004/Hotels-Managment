package com.hotel.hotel;

import com.hotel.hotel.login.LoginGridPane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ManagmentHotel extends Application implements HotelManagment {
    public void start(Stage stage, Object LoginButton) {
      LoginGridPane loginGridPane = new LoginGridPane();
      controller.instance().setLoginView(loginGridPane);
      controller.instance().setMainStage(stage);

        Scene scene = new Scene(loginGridPane,650,180,);
        stage.setTitle("Login Screen");
        stage.setScene(scene);
        stage.show();
    }

    private com.hotel.hotel.login.LoginGridPane LoginGridPane;

    @Override
    public void start() throws IOException {

    }


     public static void main (String[] args){

       //launch();

    }


    @Override
    public void start(Stage primaryStage) throws Exception {

    }
}









