package com.hotel.hotel;

import java.io.IOException;

public interface HotelManagment {
    void start() throws IOException;
}
