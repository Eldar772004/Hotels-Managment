package com.hotel.hotel;

import com.hotel.hotel.user.User;

public interface EntityManagerFactory {
    User createEntityManager();

    EntityManagerFactory createEntityManager(Object persistenceUnitName, String hotelPU);
}
