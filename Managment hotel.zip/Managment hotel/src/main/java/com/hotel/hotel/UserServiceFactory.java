package com.hotel.hotel;

import com.hotel.hotel.user.service.UserServiceLocal;

public enum UserServiceFactory {
    USER_SERVICE(new UserService());
    private static Object entitymanager;
    private UserServiceLocal userServiceLocal;

     UserServiceFactory(UserServiceLocal userServiceLocal) {
       this.userServiceLocal=userServiceLocal;

     }

    UserServiceFactory(UserService userService) {

    }

    public UserServiceLocal getUserService() {
        return userServiceLocal;
    }

    public <userService> userService get() {

        return null;
    }
}
