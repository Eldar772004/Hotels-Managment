package com.hotel.hotel;

import com.hotel.hotel.user.User;
import com.hotel.hotel.user.service.UserServiceLocal;

import java.lang.annotation.Annotation;
import java.util.List;

public class UserService<NoResultException, NonUniqueResultexception, entityManager> implements UserServiceLocal{

    private String persistenceUnitName;
    private EntityManagerFactory entityManagerFactory;
    private EntityManager getentityManager;
     private Object resultList;


     private List<User> FindAll() {
        EntityManager entityManager = getentityManager;
        EntityManager entitymanager = getentityManager();
        entityManager.getTransaction().begin();
        Query query = entityManager.createNamedQuery("UserFindAll");
        entityManager.getTransaction().commit();
        return query.getResultList();;:

    }

    private EntityManager getentityManager() {
        String entityManagerFactory = "Persistence";
        return null;
        Object query;getResultList();


    }


     public Object getResultList() {
         return resultList;
     }

     public void setResultList(Object resultList) {
         this.resultList = resultList;
     }

    @Override
    public User Login(String username, String password) {
        return null;
    }

    @Override
    public List<User> findall() {
         return null;
     }

   
    public User Login(String username) {
        return null;
    }


    public User Login(String username, String password, Object name, Throwable exception) {

        if (username == null || username.isEmpty() || password== null || password.isEmpty()) {
        return null;

    }
         EntityManager entityManager = getentityManager();
         Query query = entityManager.createNamedQuery("User.FindByUsernamePass");
         query.setParamaeter(name,"username",username);
         query.setParamaeter(name,"password",password);
         try {
             User user = (User) query.getSingleresult();
            return user;
    }catch (NoResultException| NonUniqueResultexception exception) {
             System.err.println(exception.getMessage());
             return null;
             entityManager getEntityManager;(){
                 EntityManagerFactory entityManagerFactory  = Persistence.createentityManagerFactory(persistenceUnitName"HotelPU");
                 return entityManagerFactory.createEntityManager();


             }
         }


    }
    @Override
       public void save(User user){
         EntityManager entityManager = new entityManager();
         entityManager.getTransaction().begin();
         entityManager.persist();
         entityManager.getTransaction().commit();

    }
    @Override
     public void delete(User user)  {
         EntityManager entityManager = getentityManager();
         entityManager.getTransaction().begin();
         if (!entityManager.contains(user)){
          user = entityManager.merge(user);

         }
         entityManager.remove(user);
         entityManager.getTransaction().commit();
    }
       Class<? extends Annotation> annotationType; {
    
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return null;
    }
}


    
