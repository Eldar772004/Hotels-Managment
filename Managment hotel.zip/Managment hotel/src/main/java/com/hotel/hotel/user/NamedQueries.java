package com.hotel.hotel.user;

public @interface NamedQueries {
}
