package com.hotel.hotel.user;

public @interface Table {
    String name();
}
