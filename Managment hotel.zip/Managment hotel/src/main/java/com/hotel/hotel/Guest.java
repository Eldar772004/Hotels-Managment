package com.hotel.hotel;

import com.hotel.hotel.address.Basic;
import com.hotel.hotel.address.JoinColumn;
import com.hotel.hotel.address.ManytoOne;
import com.hotel.hotel.user.*;

import java.io.Serializable;
@Entity
@Table(name = "guest")
public class Guest implements Serializable {
    @Id(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    private String document;

    @Basic(optional = false)
     private String name;
    @Basic(optional = false)
    private String surname;

    @JoinColumn(name = "id_address",referencedColumnName = "id")
    @ManytoOne(optional = false)
    private Address address;
}

