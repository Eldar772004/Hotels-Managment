package com.hotel.hotel.address;

public interface Guest {
}
