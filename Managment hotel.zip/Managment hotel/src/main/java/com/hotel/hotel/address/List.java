package com.hotel.hotel.address;

import com.hotel.hotel.privilege.Privilege;

public interface List<T> extends java.util.List<Privilege> {
}
