package com.hotel.hotel;

import com.hotel.hotel.admin.AdminBorderPane;
import com.hotel.hotel.event.EventBus;
import com.hotel.hotel.login.LoginGridPane;
import com.hotel.hotel.regular.UserBorderPane;
import com.hotel.hotel.user.User;
import javafx.stage.Stage;

public class controller {

    public static Object instance;
    private static controller INSTANCE = null;
    private LoginGridPane loginView;
     private UserBorderPane userView;
     private AdminBorderPane adminView;
     private Stage mainStage;
     private User LoggedUser;


     private final EventBus eventBus = new EventBus();

   private controller() {
   }

    public void setMainStage(Stage mainStage) {
        this.mainStage = mainStage;
    }

    public Stage getMainStage() {
        return mainStage;
    }

    public EventBus getEventBus() {
        return eventBus;
    }

    public static controller instance(){
       if(INSTANCE == null){
           INSTANCE = new controller();

       }
       return INSTANCE;

    }

    public void setLoginView(LoginGridPane loginView) {
        this.loginView = loginView;

    }

    public LoginGridPane getLoginView() {
        return loginView;
    }

    public void setAdminView(AdminBorderPane adminView) {
        this.adminView = adminView;

    }

    public AdminBorderPane getAdminView() {
        return adminView;
    }

    public void setUserView(UserBorderPane userView) {
        this.userView = userView;
    }

    public UserBorderPane getUserView() {
        return userView;
    }

    public void setLoggedUser(User loggedUser) {
        this.LoggedUser = loggedUser;
    }

    public User getLoggedUser() {
        return LoggedUser;
    }

}






