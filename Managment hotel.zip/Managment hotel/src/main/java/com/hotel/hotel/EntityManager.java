package com.hotel.hotel;

import com.hotel.hotel.user.User;
import jdk.internal.event.Event;

public interface EntityManager {
    Event getTransaction();

    Query createNamedQuery(String userFindAll);

    Object getEntityManagerFactory();

    Query createNamedQuery();

    void persist();

    void remove(User user);

    boolean contains(User user);

    void merge(User user);
}
