package com.hotel.hotel;

import com.hotel.hotel.user.User;

import java.util.List;

public interface Query {
    List<User> getResultList();

    void setParamaeter(Object o, String username, Object name);

    void getSingleresult();
}
