package com.hotel.hotel.address;

public @interface ManytoOne {
    boolean optional();
}
