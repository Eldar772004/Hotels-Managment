package com.hotel.hotel;

public @interface Entity {
}
