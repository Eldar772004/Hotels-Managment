package com.hotel.hotel.address;

public @interface GeneratedValue {
}
