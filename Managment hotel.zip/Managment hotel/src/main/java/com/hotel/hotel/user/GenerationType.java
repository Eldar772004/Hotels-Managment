package com.hotel.hotel.user;

public interface GenerationType {

    public interface IDENTITY {
    }
}
