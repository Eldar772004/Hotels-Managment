package com.hotel.hotel.room;

import com.hotel.hotel.Entity;
import com.hotel.hotel.address.OneToMany;
import com.hotel.hotel.reservation.Reservation;
import com.hotel.hotel.user.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
@Entity
@Table(name = "room")
public class Room implements Serializable {
    @Id(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional=false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    private String code;
    @Basic(optional = false)
    @Column(name ="number_of_beds")
    private int numberOfBeds;

    @Basic(optional = false)
    private BigDecimal price;
    @OneToMany(mappedBy = "room")
    private List<Reservation> reservationList;
}
