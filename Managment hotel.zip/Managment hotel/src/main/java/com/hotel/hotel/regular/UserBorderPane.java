package com.hotel.hotel.regular;

import javafx.scene.layout.BorderPane;

public class UserBorderPane extends BorderPane {
}
