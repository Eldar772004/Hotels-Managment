package com.hotel.hotel;

import javafx.stage.Stage;

public record SetTitle(Stage stage, Object stage, int loginButton) {
    public int LoginButton() {
    }
}