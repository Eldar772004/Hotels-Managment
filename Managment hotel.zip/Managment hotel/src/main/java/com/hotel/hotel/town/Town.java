package com.hotel.hotel.town;

import com.hotel.hotel.Entity;
import com.hotel.hotel.address.JoinColumn;
import com.hotel.hotel.country.Country;
import com.hotel.hotel.user.*;

import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "town")
public class Town implements Serializable {
    @Id(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    private String name;
    @JoinColumn(name = "id_country",referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Country country;




    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Country getCountry() {
        return country;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Town town = (Town) o;
        return Objects.equals(id, town.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
