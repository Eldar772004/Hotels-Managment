package com.hotel.hotel.address;

public @interface OneToMany {
    String mappedBy();
}
