package com.hotel.hotel.address;

import com.hotel.hotel.Entity;
import com.hotel.hotel.town.Town;
import com.hotel.hotel.user.Column;
import com.hotel.hotel.user.Id;
import com.hotel.hotel.user.Table;
import java.io.Serializable;
import java.util.Objects;
import java.util.List;

import static com.hotel.hotel.address.GenerationType.*;

@Entity
@Table(name = "address")

public class address implements Serializable {

    @Id(name = "id")
    @GeneratedValue(strategy =GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")

  private Integer Id;
    @Basic(optional = false)
    @Column(name = "street")
    private String street;
    @Basic(optional = false)
    @Column(name = "number")

    private String Number;
    @JoinColumn(name = "id_town",referencedColumnName = "id")
    @ManytoOne(optional = false)
    private Town town;

    @OneToMany(mappedBy = "address")
    private List<Guest> guestList;


    public address() {
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public Town getTown() {
        return town;
    }

    public void setTown(Town town) {
        this.town = town;
    }

    public List<Guest> getGuestList() {
        return guestList;
    }

    public void setGuestList(List<Guest> guestList) {
        this.guestList = guestList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        address address = (address) o;
        return Objects.equals(Id, address.Id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Id);
    }
}


