package com.hotel.hotel.reservation;

import com.hotel.hotel.Entity;
import com.hotel.hotel.Guest;
import com.hotel.hotel.address.JoinColumn;
import com.hotel.hotel.address.ManytoOne;
import com.hotel.hotel.room.Room;
import com.hotel.hotel.user.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

import static com.hotel.hotel.user.GenerationType.*;

@Entity
@Table(name = "reservation")
public class Reservation implements Serializable {


    @Id(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @JoinColumn(name = "id_guest",referencedColumnName = "id")
    @ManytoOne(optional = false)
    private Guest mainGuest;

    @JoinColumn(name = "id_room",referencedColumnName = "id")
    @ManytoOne(optional = false)
    private Room room;
    @Basic(optional = false)
    @Column(name = "from_date")
    private LocalDateTime fromDate;

    @Basic(optional = false)
    @Column(name = "to_date")
    private LocalDateTime toDate;
    @Basic(optional = false)
    private Boolean checkin;


    @Basic(optional = false)
    @Column(name = "checkin_date_time")
    private LocalDateTime checkinDateTime;

    @Basic(optional = false)
    private Boolean checkout;

    @Basic(optional = false)
    @Column(name = "checkout_date_time")
    private LocalDateTime checkoutDateTime;

public class reservation {
}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Guest getMainGuest() {
        return mainGuest;
    }

    public void setMainGuest(Guest mainGuest) {
        this.mainGuest = mainGuest;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public LocalDateTime getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDateTime fromDate) {
        this.fromDate = fromDate;
    }

    public LocalDateTime getToDate() {
        return toDate;
    }

    public void setToDate(LocalDateTime toDate) {
        this.toDate = toDate;
    }

    public Boolean getCheckin() {
        return checkin;
    }

    public void setCheckin(Boolean checkin) {
        this.checkin = checkin;
    }

    public LocalDateTime getCheckinDateTime() {
        return checkinDateTime;
    }

    public void setCheckinDateTime(LocalDateTime checkinDateTime) {
        this.checkinDateTime = checkinDateTime;
    }

    public Boolean getCheckout() {
        return checkout;
    }

    public void setCheckout(Boolean checkout) {
        this.checkout = checkout;
    }

    public LocalDateTime getCheckoutDateTime() {
        return checkoutDateTime;
    }

    public void setCheckoutDateTime(LocalDateTime checkoutDateTime) {
        this.checkoutDateTime = checkoutDateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservation that = (Reservation) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
