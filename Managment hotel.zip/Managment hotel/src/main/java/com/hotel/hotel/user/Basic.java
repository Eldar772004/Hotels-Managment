package com.hotel.hotel.user;

public @interface Basic {
    boolean optional();
}
