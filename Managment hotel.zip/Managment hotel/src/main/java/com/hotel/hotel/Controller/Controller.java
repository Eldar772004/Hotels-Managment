package com.hotel.hotel.Controller;

import com.hotel.hotel.controller;
import com.hotel.hotel.login.LoginGridPane;

public class Controller {
    public static LoginGridPane instance;

    public static controller instance() {
        return null;

    }
}
