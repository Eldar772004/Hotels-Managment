package com.hotel.hotel.privilege;

import com.hotel.hotel.Entity;
import com.hotel.hotel.address.OneToMany;
import com.hotel.hotel.user.*;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import static com.hotel.hotel.user.GenerationType.*;

@Entity
@Table(name = "privilege")
@NamedQueries()
        @NamedQuery(name = "Privilege.findAll",query = "SELECT p privilege p FROM Privilege p")
public class Privilege implements Serializable {




  @Id(name = "id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "id")
  private Integer id;

  @Basic(optional = false)
  private String name;


  @OneToMany(mappedBy = "privilege")
  private List<User> userList;

  public Privilege() {
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<User> getUserList() {
    return userList;
  }

  public void setUserList(List<User> userList) {
    this.userList = userList;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Privilege privilege = (Privilege) o;
    return Objects.equals(id, privilege.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }
}



