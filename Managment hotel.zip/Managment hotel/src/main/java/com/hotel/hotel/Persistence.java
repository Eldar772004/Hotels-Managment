package com.hotel.hotel;

public class Persistence {


    public static EntityManagerFactory createentityManagerFactory;
}
