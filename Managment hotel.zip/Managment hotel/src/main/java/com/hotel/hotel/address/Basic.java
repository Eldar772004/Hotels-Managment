package com.hotel.hotel.address;

public @interface Basic {
    boolean optional();
}
