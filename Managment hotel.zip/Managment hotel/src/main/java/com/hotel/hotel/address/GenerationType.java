package com.hotel.hotel.address;

public enum GenerationType {
    ;
    public static Object IDENTITY;
}
