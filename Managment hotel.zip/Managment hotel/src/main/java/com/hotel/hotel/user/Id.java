package com.hotel.hotel.user;

public @interface Id {
    String name();
}
