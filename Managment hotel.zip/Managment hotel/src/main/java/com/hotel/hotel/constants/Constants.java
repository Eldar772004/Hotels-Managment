package com.hotel.hotel.constants;

public interface Constants {
    String PU_NAME = ""hotelPu""

}
