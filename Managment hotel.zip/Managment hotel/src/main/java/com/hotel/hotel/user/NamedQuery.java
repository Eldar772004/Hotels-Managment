package com.hotel.hotel.user;

public @interface NamedQuery {
    String name();

    String query();
}
