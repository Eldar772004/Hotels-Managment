package com.hotel.hotel.privilege.service;

import com.hotel.hotel.EntityManager;
import com.hotel.hotel.EntityManagerFactory;
import com.hotel.hotel.Persistence;
import com.hotel.hotel.Query;
import com.hotel.hotel.address.List;
import com.hotel.hotel.privilege.Privilege;

public class PrivilegeService implements PrivilegeServiceLocal {
    private Object persistenceUnitName;

    @Override
    public List<Privilege> findAll() {
        EntityManager entityManager = getentityManager();
        Query query = entityManager.createNamedQuery("Privilege.findAll");
        return query.getResultList();

    }

    private EntityManager getentityManager() {
        EntityManagerFactory entityManagerFactory = Persistence.createentityManagerFactory.createEntityManager(persistenceUnitName,"HotelPU");
        return (EntityManager) entityManagerFactory.createEntityManager();
    }

}