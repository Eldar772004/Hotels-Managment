package com.hotel.hotel.privilege.service;

import com.hotel.hotel.address.List;
import com.hotel.hotel.privilege.Privilege;

public interface PrivilegeServiceLocal {


    PrivilegeServiceLocal  SERVICE = new PrivilegeService();

    List<Privilege> findAll();

}
