package com.hotel.hotel.address;

public @interface JoinColumn {
    String name();

    String referencedColumnName();
}
