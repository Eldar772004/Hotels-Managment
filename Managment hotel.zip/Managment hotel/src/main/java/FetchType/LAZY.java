package FetchType;

public interface LAZY {
}
