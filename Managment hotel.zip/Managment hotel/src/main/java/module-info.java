module com.hotel.hotel {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.naming;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;
    requires java.sql;
    requires java.sql.rowset;
    requires org.controlsfx.controls;



    opens com.hotel.hoteli to javafx.fxml;
    opens com.hotel.hotel.gui.components to javafx.base;
    opens com.hotelijerstvo.hotel.country.town.address to org.hibernate.orm.core;
    opens com.hotelijerstvo.hotel.country.town.to ;org.hibernate.orm.core;
    opens com.hotelijerstvo.hotel.country.to.org.hibernate.orm.core;
    opens com.hotel.hotel.user to org.hibernate.orm.core;
    opens com.hotel.hotel.user.privilege to org.hibernate.orm.core;
    opens com.hotel.hotel.country.town.address.to.org.hibernate.orm.core;
    opens com.hotel.hotel.reservation to org.hibernate.orm.core;
    opens com.hotel.hotel.reservation.guest to org.hibernate.orm.core;
    opens com.hotel.hotel.reservation.room to org.hibernate.orm.core;

    exports com.hotel.hotel;
    opens com.hotel.hotel.user.service to org.hibernate.orm.core;
}